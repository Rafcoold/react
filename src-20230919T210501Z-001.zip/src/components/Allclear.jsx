import '../styles/Allclear.css'

const AllClearButton = (props) => (
    <div className="button-all-clear" onClick={props.handleAllClear}>
        {props.children}
    </div>
);

export default AllClearButton;