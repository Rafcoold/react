import '../styles/Button.css';

function Button (props){

    const Operator = value => {
        return isNaN(value) && (value!=='.') && (value!=='=');
    }

    return (
        <div className={`container-btn ${Operator(props.children) ? 'operator' : ''}`.trimEnd()}
        onClick={() => props.handleClick(props.children)}>
            {props.children}
        </div>
    )
}

export default Button;