import "./App.css";
import Button from "./components/Button";
import Input from "./components/Input";
import ClearButton from "./components/Clear";
import AllClearButton from "./components/Allclear";
import { useState } from "react";
import { evaluate } from "mathjs";

function App() {
  const [input, setInput] = useState("");

  const addToInput = (val) => {
    if (input === "00") {
      return setInput("0");
    }else{
     return setInput(input + val);
    }
  };

  const clearLast = () => {
    if (input === 'string') {
      return setInput(input.slice(0, -1)); 
    }else{
      return setInput(input.toString().slice(0, -1))
    }
    
  };

  const calcResult = () => {
    if (input){
      return setInput(evaluate(input));
    }else{ 
      return setInput("0");
    }
  };


  return (
    <div className="App">
      <div className="calc-container">
        <Input input={input} />
        <div className="fila">
          <Button handleClick={addToInput}>7</Button>
          <Button handleClick={addToInput}>8</Button>
          <Button handleClick={addToInput}>9</Button>
          <Button handleClick={addToInput}>+</Button>
        </div>
        <div className="fila">
          <Button handleClick={addToInput}>4</Button>
          <Button handleClick={addToInput}>5</Button>
          <Button handleClick={addToInput}>6</Button>
          <Button handleClick={addToInput}>-</Button>
        </div>
        <div className="fila">
          <Button handleClick={addToInput}>1</Button>
          <Button handleClick={addToInput}>2</Button>
          <Button handleClick={addToInput}>3</Button>
          <Button handleClick={addToInput}>*</Button>
        </div>
        <div className="fila">
          <Button handleClick={calcResult}>=</Button>
          <Button handleClick={addToInput}>0</Button>
          <Button handleClick={addToInput}>.</Button>
          <Button handleClick={addToInput}>/</Button>
        </div>
        <div className="fila">
          <AllClearButton handleAllClear={() => setInput("")}>
            All Clear
          </AllClearButton>
          <ClearButton handleClear={clearLast}>
            Clear
          </ClearButton>
        </div>
      </div>
    </div>
  );
}

export default App;
